#!/bin/bash                                                                              
gcc -g gdb_arr1.c -o gdb_arr1
gdb ./gdb_arr1

# Utilice las siguientes comandos
#   break main
#   run
#   next
#       print arr[0]
#       print arr
#   next
#       print arr
#   break 9
#   print suma
#   continue
#   exit