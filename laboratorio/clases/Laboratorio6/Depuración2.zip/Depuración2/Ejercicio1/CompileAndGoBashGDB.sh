#!/bin/bash                                                                              
gcc -g gdb_arr1.c -o gdb_arr1

# Utilice las siguientes comandos
gdb -ex "break main" -ex "run" -ex  "next" -ex "print arr" -ex "continue" -ex "exit" ./gdb_arr1

#   break main
#   run
#   next
#       print arr[0]
#       print arr
#   next
#       print arr
#   break 9
#   print suma
#   continue
#   exit