#!/bin/bash                                                                              
gcc -g gdb_ptr.c -o gdb_ptr
gdb ./gdb_ptr

# Recordatorio de comandos
# run        # ejecutar programa
# break main # breakpoint función
# break N    # breakpoint linea N
# next       # siguiente línea
# step       # entrar en funciones
# print x    # ver valor de variable x
# continue   # continuar ejecución

# Ver como progresa i y el puntero
# en dgb usar una vez lleguen adentro del ciclo
# print i
# print *(p + i)
# print *(p + i + 1)