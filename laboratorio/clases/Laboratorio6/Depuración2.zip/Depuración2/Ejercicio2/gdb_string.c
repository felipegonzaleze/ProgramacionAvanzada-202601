#include <stdio.h>

int main(){
    char str[] = "programacion";
    int contador = 0;

    for(int i = 0; i < 20; i++){
        if(str[i] == 'a'){
            contador++;
        }
    }

    return 0;
}