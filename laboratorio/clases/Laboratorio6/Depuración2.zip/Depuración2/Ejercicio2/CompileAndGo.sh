#!/bin/bash                                                                              
gcc -g gdb_string.c -o gdb_string
gdb ./gdb_string

# Recordatorio de comandos
# run        # ejecutar programa
# break main # breakpoint función
# break N    # breakpoint linea N
# next       # siguiente línea
# step       # entrar en funciones
# print x    # ver valor de variable x
# continue   # continuar ejecución