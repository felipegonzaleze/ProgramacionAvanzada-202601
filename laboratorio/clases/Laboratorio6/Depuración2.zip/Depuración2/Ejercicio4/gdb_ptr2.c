#include <stdio.h>

int main(){
    char str[] = "debug";
    char *p = str;

    while(*p != '\0'){
        if(*p == 'e'){
            p++;
        }
        p++;
    }

    return 0;
}