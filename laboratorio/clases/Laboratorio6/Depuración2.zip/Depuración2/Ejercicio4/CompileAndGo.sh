#!/bin/bash                                                                              
gcc -g gdb_ptr2.c -o gdb_ptr2
gdb ./gdb_ptr2

# Recordatorio de comandos
# run        # ejecutar programa
# break main # breakpoint función
# break N    # breakpoint linea N
# next       # siguiente línea
# step       # entrar en funciones
# print x    # ver valor de variable x
# continue   # continuar ejecución