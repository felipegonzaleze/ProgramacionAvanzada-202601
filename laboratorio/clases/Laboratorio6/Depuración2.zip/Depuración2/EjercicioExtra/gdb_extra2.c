#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int *datos;
    int n;
} Lista;

int main(){
    Lista lista;

    lista.n = 5;
    lista.datos = malloc(lista.n * sizeof(int));

    // llenar
    for(int i = 0; i < lista.n; i++){
        lista.datos[i] = i * 2;
    }

    int suma = 0;

    // revisar
    for(int i = 0; i <= lista.n; i++){
        suma += lista.datos[i];

        if(lista.datos[i] % 2 == 0){
            i++;
        }
    }

    printf("Suma = %d\n", suma);

    free(lista.datos);
    return 0;
}