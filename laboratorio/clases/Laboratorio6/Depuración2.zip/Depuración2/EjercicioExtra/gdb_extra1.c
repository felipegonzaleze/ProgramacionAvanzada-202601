#include <stdio.h>

typedef struct{
    int valor;
} Celda;

int main(){
    Celda matriz[2][2] = {
        {{1},{2}},
        {{3},{4}}
    };

    int suma = 0;

    for(int i = 0; i < 2; i++){
        for(int j = 0; j <= 2; j++){
            suma += matriz[i][j].valor;
        }
    }

    printf("Suma = %d\n", suma);
    return 0;
}