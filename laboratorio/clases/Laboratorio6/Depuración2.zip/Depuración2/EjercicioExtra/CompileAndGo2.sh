#!/bin/bash                                                                              
gcc -g gdb_extra2.c -o gdb_extra2
gdb ./gdb_extra2

# Recordatorio de comandos
# run        # ejecutar programa
# break main # breakpoint función
# break N    # breakpoint linea N
# next       # siguiente línea
# step       # entrar en funciones
# print x    # ver valor de variable x
# continue   # continuar ejecución

# analice y corriga el programa gdb_extra2