#include <stdio.h>

int main(){
    int datos[5] = {10, 20, 30, 40, 50};
    int suma = 0;
    int promedio;

    for(int i = 0; i < 5; i++){
        suma += datos[i];
    }

    promedio = suma / 5;

    printf("Promedio = %d\n", promedio);
    return 0;
}
